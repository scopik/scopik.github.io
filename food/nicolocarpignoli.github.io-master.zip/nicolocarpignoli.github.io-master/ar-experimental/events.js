// register our component
AFRAME.registerComponent('cursor-listener', {
    init: function() {
        this.el.addEventListener('click', function(ev){
            console.log('deatil', ev.detail.intersection);
            console.log('cursorEl', ev.detail.cursorEl);
            console.log('targetEl', ev.detail.targetEl);
        });
}});
